<?php
  $Name = $_GET['Name'];
  $Email = $_GET['Email'];
  echo "姓名:".$Name."<br/>Email:".$Email;
?>